package com.example.demo.Repoistory;

import com.example.demo.Entity.Cart;
import com.example.demo.Entity.Products;
import org.springframework.data.repository.CrudRepository;

public interface CartRepository extends CrudRepository<Cart,Integer> {

}
