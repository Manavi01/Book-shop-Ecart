package com.example.demo.Controller;

import java.util.List;

import com.example.demo.Entity.Cart;
import com.example.demo.Entity.Products;
import com.example.demo.Repoistory.CartRepository;
import com.example.demo.Repoistory.ProductRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.servlet.ModelAndView;

@Controller
public class prodcutController {

    @Autowired
    ProductRepository productRepository;
    ModelAndView modelAndView=new ModelAndView();
    @Autowired
    CartRepository cartRepository;


    Products pro = new Products();


    @RequestMapping("/productpage")
    public ModelAndView product() {

        List<Products> productList = (List<Products>) productRepository.findAll();
        modelAndView.addObject("products", productList);
        modelAndView.setViewName("read");

        return modelAndView;
    }
    @RequestMapping("/addtocart")
    public ModelAndView addtocart(Cart cart)
    {

        pro = productRepository.findById(cart.getProductid()).orElse(new Products());
        cart.setProductname(pro.getBookname());
        cart.setProductimg(pro.getBookimg());
        cart.setProductprize(pro.getBookprize());
        cartRepository.save(cart);
        List<Cart> cartList =(List<Cart>) cartRepository.findAll();
        modelAndView.addObject("carts",cartList);
        modelAndView.setViewName("cart");
        return modelAndView;

    }
    @RequestMapping("/order")
    public String order()
    {
        return"order";
    }

}
