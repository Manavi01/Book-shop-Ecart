package com.example.demo.Entity;

import org.hibernate.annotations.RowId;

import javax.persistence.*;

@Entity
public class Register {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public int id;

    public String name;

    public String password;


    public String emailId;

    public String mobileNo;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }


    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }

    public Register() {

    }

    @Override
    public String toString() {
        return "Register [ emailId=" + emailId + ", id=" + id + ", mobileNo=" + mobileNo + ", name=" + name
                + ", password=" + password + "]";
    }

}

/*
 * public Register(int id, String name, String password, String
 * confirm_password, String email_id, int mobile_no) { this.id = id; this.name =
 * name; this.password = password; this.confirm_password = confirm_password;
 * this.email_id = email_id; this.mobile_no = mobile_no; }
 */
