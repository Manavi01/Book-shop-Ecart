package com.example.demo.Repoistory;

import com.example.demo.Entity.Register;

import org.springframework.data.repository.CrudRepository;

public interface RegisterRepository extends CrudRepository<Register, Integer> {

    public Register findByEmailId(String emailId);

}
